load -ascii Seite_126_Kapitel_9_2_data_y.csv;  
y = Seite_126_Kapitel_9_2_data_y; 
u = zeros(1,length(y));

R = 0.06;
Q = 0.00025;

K = -0.5*Q/R + sqrt(0.25*(Q/R)^2 + Q/R); 
P = Q/K;

x(1) = y(1); 

%%% ZYKLISCHE BERECHNUNG KALMAN-FILTER %%%
for k=1:length(y)
  x(k+1) = x(k) + K*(y(k) - x(k));
end 

figure(1); 
l = length(y); 
k = [1:l];
plot(k,y,'b-',k,x(1:l),'r--'); grid on;
axis([1 l -0.8 2.3]);
xlabel('k'); 
legend('gemessenes Signal','gefiltertes Signal');

