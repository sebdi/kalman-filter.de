syms Ts 'real';

A = [0 1 0; 
     0 0 1; 
     0 0 0];
C = [1 0 0;
     0 0 1]; 
		
Ad = simplify(expm(Ts*A));

SB=C; 
for n=1:length(A)-1
  SB = [SB; C*Ad^n]; 
end

rank(SB)
