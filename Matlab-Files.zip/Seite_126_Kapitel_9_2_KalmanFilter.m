load -ascii Seite_126_Kapitel_9_2_data_y.csv;  
y = Seite_126_Kapitel_9_2_data_y; 
u = zeros(1,length(y));

%%% INITIALISIERUNG KALMAN-FILTER %%%
R = 0.06;
Q = 0.00025;
x(1) = y(1); 
P(1) = Q; 

%%% ZYKLISCHE BERECHNUNG KALMAN-FILTER %%%
for k=1:length(y)
  K(k) = P(k)/(P(k) + R);
  x(k+1) = x(k) + K(k)*(y(k) - x(k));
  P(k+1) = (1 - K(k))*P(k) + Q;
end 

figure(1); 
l = length(y); 
k = [1:l];
plot(k,y,'b-',k,x(1:l),'r--'); grid on;
axis([1 l -0.8 2.3]);
xlabel('k'); 
legend('gemessenes Signal','gefiltertes Signal');

figure(2); 
subplot(211);
plot(k,K(1:l),'b-'); grid on;
axis([1 l -0.5e-2 7e-2]);
xlabel('k'); ylabel('K(k)');

subplot(212);
plot(k,P(1:l),'b-'); grid on;
axis([1 l -0.5e-3 5e-3]);
xlabel('k'); ylabel('P(k)');
