syms Ts 'real';

A = [0 1 0 0;
     0 0 1 0;
     0 0 0 0;
     0 0 0 0];
B = [0; 0; 0; 0];

Ad = simplify(expm(Ts * A))
Bd = simplify(int(expm(Ts * A) * B))
