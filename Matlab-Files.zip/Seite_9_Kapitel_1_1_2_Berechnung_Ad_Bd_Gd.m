syms Ts 'real';

A = [0 1 0; 
     0 0 1; 
     0 0 0];
B = [0; 0; 0];
G = [0; 0; 1];

Ad = simplify(expm(Ts*A))
Bd = simplify(int(expm(Ts*A)*B))
Gd = Ad*G
