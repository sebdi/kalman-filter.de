load -ascii Seite_19_Kapitel_1_4_data_y.csv;  
t = Seite_19_Kapitel_1_4_data_y(:,1);
y = Seite_19_Kapitel_1_4_data_y(:,2); 
u = Seite_19_Kapitel_1_4_data_y(:,3); 

Ts = 0.1;
R  = 20;
Q  = 0.2;

Ad = [1 Ts;  0 1]; 
Bd = [.5*Ts^2;  Ts];
C  = [1 0];
G  = Bd;
GQG = G*Q*G';


%%% INITIALISIERUNG KALMAN-FILTER %%%
x = [y(1,1); 0];
P = 3*[1 0; 0 1]; 


%%% VORABBESTIMMUNG VON P UND K  %%%
for k=1:200
  K = P*C'*pinv(C*P*C' + R);
  P = (eye(length(Bd)) - K*C)*P;
  P = Ad*P*Ad' + GQG;
end


%%% ZYKLISCHE BERECHNUNG KALMAN-FILTER %%%
for k=1:length(y)
  x = x + K*(y(k,:)' - C*x);
	
  s(k) = x(1);  v(k) = x(2);  
	
  x = Ad*x + Bd*u(k);
end

figure(1); 
subplot(211);
plot(t,v,'r--'); grid on;
xlabel('Zeit[s]'); ylabel('Geschwindigkeit [m/s]'); 
legend('gesch�tztes Signal');

subplot(212);
plot(t,y(:,1),'b-',t,s,'r--'); grid on;
xlabel('Zeit[s]'); ylabel('Position [m]'); 
legend('gemessenes Signal','gefiltertes Signal');

