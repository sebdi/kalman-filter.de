clear all;

load -ascii Seite_168_Kapitel_12_2_data_t_h_v_a_y_r1_r2_r3.csv 
t = Seite_168_Kapitel_12_2_data_t_h_v_a_y_r1_r2_r3(:,1)'; 
y = Seite_168_Kapitel_12_2_data_t_h_v_a_y_r1_r2_r3(:,5:7)';

Gamma   = 2.5;            % Verst�rkungsfaktor Messrauschen  
Alpha_R = 0.05;           % Kalman-Verst�rkung Varianz Messrauschen
Alpha_M = 0.1;            % Kalman-Verst�rkung Varianz M 
Q_min   = 3E-3;           % min. Q-Wert
Q_max   = 3E-1;           % max. Q-Wert

Ts      = 0.01;           % Abtastzeit

%---  V O R A B B E S T I M M U N G   V O N   K0   u n d   H  ---
Ad = [1 Ts; 
      0 1]; 
C  = [1 0];

R0  = 1;
Q0  = 1;

lambda = Ts*sqrt(Q0/R0);
K1 = -1/8*(lambda.^2 + 8*lambda - (lambda+4).*sqrt(lambda.^2+8*lambda));
K2 = .25*(lambda.^2 + 4*lambda - lambda.*sqrt(lambda.^2+8*lambda))/Ts;

K0= [K1;K2];
H = (eye(length(Ad)) - K0*C)*Ad;

%---  I N I T   R O S E - F I L T E R  ---

y1 = y(1,1);
y2 = y(2,1); 

x1 = [y1;y2;];
x2 = [y2;0]; 

x = [y1; y2; 0;];   

R = [1 0; 
     0 0.1];

Ad = [1  Ts .5*Ts^2;
      0  1   Ts;
      0  0   1]; 
Bd = [0; 0; 0];
C  = [1 0 0;
      0 1 0];
D  = [0; 0];
G  = [0.5*Ts^2;
      Ts;
      1]; 
GG = G*G';

u = zeros(1,length(t));
p_tilde = [0.5 0 0; 
           0 0.1 0;
           0 0 0.1]; 
M = C*p_tilde*C';


%---  R O S E - F I L T E R  ---

for k=1:length(y)
  %--- Bestimmung Messrauschen ---
  y1 = y(1,k);
  y2 = y(2,k); 
  x1 = H*x1 + K0*y1; 
  x2 = H*x2 + K0*y2;
  R  = Gamma*Alpha_R*[x1(1)-y1; x2(1)-y2]*[x1(1)-y1; x2(1)-y2]' + (1-Alpha_R)*R;
  R(2)=0; R(3)=0;     % unter der Annahme, dass die Kovarianz = 0 ist 
  
  %--- Bestimmung Systemrauschen ---
  dy    = y(1:2,k) - C*x - D*u(k);     
  M     = Alpha_M.*dy*dy' + (1-Alpha_M).*M;
  Q(k) = (M(4)-R(4)-p_tilde(5)-Ts*(2*p_tilde(6)+p_tilde(9)*Ts))/Ts^2;
    
  if Q(k)<Q_min
    Q(k)=Q_min;  
  end
  
  if Q(k)>Q_max
    Q(k)=Q_max;
  end
    
  %--- Kalman Gleichungen ---
  p_dach  = Ad*p_tilde*Ad' + GG*Q(k);
  K       = p_dach*C'*pinv(C*p_dach*C' + R); 
  x       = x + K*dy;
  
  s(k)=x(1); v(k)=x(2); a(k)=x(3);
  R1(k)=R(1); R4(k)=R(4); 
  
  p_tilde = (eye(length(Bd)) - K*C)*p_dach;
  x       = Ad*x + Bd*u(k);
end



figure(1); 
subplot(311);
plot(t,y(1,:),'b-',t,s,'r--'); grid on;
xlabel('Zeit[s]'); ylabel('Position [m]'); 
legend('gemessenes Signal','gefiltertes Signal');

subplot(312);
plot(t,y(2,:),'b-',t,v,'r--'); grid on;
xlabel('Zeit[s]'); ylabel('Geschwindigkeit [m/s]'); 
legend('gemessenes Signal','gefiltertes Signal');

subplot(313);
plot(t,a,'r--'); grid on;
xlabel('Zeit[s]'); ylabel('Beschleunigung [m/s^2]'); 
legend('gesch�tztes Signal');


r1= Seite_168_Kapitel_12_2_data_t_h_v_a_y_r1_r2_r3(:,8)';
r2= Seite_168_Kapitel_12_2_data_t_h_v_a_y_r1_r2_r3(:,9)';

figure(2); 
subplot(211); 
plot(t,R1/Gamma,'b-',t,r1,'r--'); grid on; 
ylabel('R_{1,1}(t)/\gamma'); xlabel('Zeit[s]');
legend('gesch�tzte Gr��e','wahre Gr��e');

subplot(212); 
plot(t,R4/Gamma,'b-',t,r2,'r--'); grid on; 
ylabel('R_{2,2}(t)/\gamma'); xlabel('Zeit[s]');
legend('gesch�tzte Gr��e','wahre Gr��e');

figure(3); 
plot(t,Q,'b-'); grid on;
axis([t(1) t(end) 0 0.5]);
ylabel('Q(t) [m^2/s^4]'); xlabel('Zeit[s]');
